// En estas primeras 6 preguntas, reemplaza `null` por la respuesta

// Crea una variable "string", puede contener lo que quieras:
const nuevaString = null;

// Crea una variable numérica, puede ser cualquier número:
const nuevoNum = null;

// Crea una variable booleana:
const nuevoBool = null;

// Resuelve el siguiente problema matemático:
const nuevaResta = 10 - null === 5;

// Resuelve el siguiente problema matemático:
const nuevaMultiplicacion = 10 * null === 40 ;

// Resuelve el siguiente problema matemático:
const nuevoModulo = 21 % 5 === null;

// No modificar nada debajo de esta línea
// --------------------------------

module.exports = {
  nuevaString,
  nuevoNum,
  nuevoBool,
  nuevaResta,
  nuevaMultiplicacion,
  nuevoModulo,
};